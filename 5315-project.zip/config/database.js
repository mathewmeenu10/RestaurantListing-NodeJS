module.exports = {
    url : process.env.DB_CONNECTION_STRING
};